data class Jobs(
    val title: String= "",
    val description: String= "",
    val category: String= "",
    val experience: String= "",
    val attainment: String= "",
    val company: String= "",
    val companyDescription: String= "",
    val salary: String = "",
    val companyAddress: String= ""
)
