data class Payment(
    val currUser: String= "",
    val mentorName: String= "",
    val paymentMethod: String= "",
    val paymentAmount: String= "",
    val imageUrl: String= "",
    val bookingID: String = ""
)