data class Contribution(
    val id: String = "" ,
    val mentorName: String= "" ,
    val title: String = "" ,
    val content: String= "" ,
    val datePublished: String = "" ,
    val imageUrl: String = ""
)