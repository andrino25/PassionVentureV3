data class Resume(
    val jobCompany: String = "",
    val jobTitle: String = "",
    val resumeUrl: String = "",
    val username: String = ""
)
