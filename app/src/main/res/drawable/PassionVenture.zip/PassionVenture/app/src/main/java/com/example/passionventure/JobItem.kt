package com.example.passionventure

data class JobItem(
    val jobDesc: String,
    val jobCompany: String,
    val jobCategory: String
)